const NodeClam = require("clamscan");

let clamscan;

const initScanner = async () => {
  clamscan = await new NodeClam().init({
    clamdscan: {
      active: true,
      host: "127.0.0.1",
      port: 3310,
      timeout: 60000
    },
    preference: "clamdscan"
  });
};

const scanFile = async (filePath) => {
  if (!clamscan) {
    await initScanner();
  }

  const { isInfected, viruses } = await clamscan.scanFile(filePath);
  return { isInfected, viruses };
};

module.exports = { scanFile };
