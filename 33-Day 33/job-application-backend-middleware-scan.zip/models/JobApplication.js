
const mongoose = require("mongoose");

const jobSchema = new mongoose.Schema(
  {
    fullName: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    phone: { type: String, required: true },
    position: { type: String, required: true },
    experience: { type: Number },
    coverLetter: { type: String },
    profileImage: { type: String },
    resume: { type: String },
    status: {
      type: String,
      enum: ["pending", "reviewed", "rejected"],
      default: "pending"
    }
  },
  { timestamps: true }
);

module.exports = mongoose.model("JobApplication", jobSchema);
