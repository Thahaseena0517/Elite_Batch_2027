const express = require("express");
const mongoose = require("mongoose");
const jobRoutes = require("./routes/jobRoutes");

const app = express();

app.use(express.json());
app.use("/uploads", express.static("uploads"));

mongoose.connect("mongodb://localhost:27017/job_app_middleware")
  .then(() => console.log("MongoDB connected"))
  .catch(err => console.error(err));

app.use("/jobs", jobRoutes);

app.listen(3000, () => {
  console.log("Server running on port 3000");
});
