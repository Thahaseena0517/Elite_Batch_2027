
const express = require("express");
const router = express.Router();
const upload = require("../middleware/upload");
const Job = require("../models/JobApplication");
const { jobValidation } = require("../middleware/validation");
const { validationResult } = require("express-validator");
const virusScanMiddleware = require("../middleware/virusScanMiddleware");

router.post(
  "/apply",
  upload.fields([
    { name: "profileImage", maxCount: 1 },
    { name: "resume", maxCount: 1 }
  ]),
  virusScanMiddleware,
  jobValidation,
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const job = new Job({
        ...req.body,
        profileImage: req.files?.profileImage?.[0]?.filename,
        resume: req.files?.resume?.[0]?.filename
      });

      await job.save();

      res.status(201).json({
        message: "Application submitted successfully"
      });

    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  }
);

module.exports = router;
