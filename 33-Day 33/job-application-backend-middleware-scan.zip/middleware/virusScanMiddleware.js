const fs = require("fs");
const { scanFile } = require("../services/virusScanner");

const virusScanMiddleware = async (req, res, next) => {
  try {
    const files = req.files;

    if (!files) return next();

    for (const key in files) {
      const filePath = files[key][0].path;

      const { isInfected, viruses } = await scanFile(filePath);

      if (isInfected) {
        fs.unlinkSync(filePath);
        return res.status(400).json({
          error: "Virus detected!",
          
          viruses
        });
      }
    }

    next();

  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
};

module.exports = virusScanMiddleware;
