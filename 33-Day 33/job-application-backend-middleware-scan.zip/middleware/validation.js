
const { body } = require("express-validator");

exports.jobValidation = [
  body("fullName").notEmpty().withMessage("Full Name is required"),
  body("email").isEmail().withMessage("Valid email required"),
  body("phone").notEmpty().withMessage("Phone is required"),
  body("position").notEmpty().withMessage("Position is required")
];
